import Catalogo from './components/Catalogo';

function App() {
  return (
    <div>
      <Catalogo />
    </div>
  )
}

export default App;