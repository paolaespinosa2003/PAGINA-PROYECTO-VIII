import { useState, useEffect } from 'react';
import api from '../services/api';

const Catalogo = () => {
    const [productos, setProductos] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const obtenerProductos = async () => {
            try {
                const respuesta = await api.get('/products'); 
                setProductos(respuesta.data);
                setCargando(false);
            } catch (error) {
                console.error("Error al obtener los productos:", error);
                setCargando(false);
            }
        };

        obtenerProductos();
    }, []);

    // Estado de Carga Profesional
    if (cargando) {
        return (
            <div className="flex justify-center items-center min-h-screen bg-gray-900">
                <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.5)]"></div>
            </div>
        );
    }

    return (
        // Fondo principal oscuro
        <div className="min-h-screen bg-gray-900 py-16 px-4 sm:px-6 lg:px-8 font-sans">
            <div className="max-w-7xl mx-auto">
                
                {/* Encabezado Moderno */}
                <div className="text-center mb-16">
                    <h2 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400 sm:text-5xl tracking-tight">
                        Catálogo de Productos
                    </h2>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-400">
                        
                    </p>
                </div>

                {/* Cuadrícula de Productos */}
                <div className="grid grid-cols-1 gap-y-12 sm:grid-cols-2 sm:gap-x-6 lg:grid-cols-3 xl:gap-x-8">
                    {productos.map((producto) => (
                        <div 
                            key={producto.id} 
                            // Tarjeta con efecto glassmorphism oscuro y glow al pasar el mouse
                            className="group relative bg-gray-800 border border-gray-700 rounded-2xl shadow-lg hover:shadow-[0_0_30px_rgba(99,102,241,0.15)] transition-all duration-300 overflow-hidden flex flex-col transform hover:-translate-y-2"
                        >
                            {/* Área de Imagen Placeholder Elegante */}
                            <div className="w-full h-56 bg-gray-700 flex items-center justify-center relative overflow-hidden">
                                {/* Efecto de gradiente sobre la imagen vacía */}
                                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-800/90 z-10"></div>
                                <svg className="h-20 w-20 text-gray-600 group-hover:scale-110 transition-transform duration-500 z-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <span className="absolute bottom-4 left-4 text-gray-400 font-medium z-20 text-sm uppercase tracking-wider">Próximamente Imagen</span>
                            </div>

                            {/* Contenido de la Tarjeta */}
                            <div className="p-6 flex-1 flex flex-col relative z-20">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-xl font-bold text-white group-hover:text-indigo-400 transition-colors duration-200">
                                        {producto.name}
                                    </h3>
                                    {/* Badge de Stock moderno */}
                                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                        Stock: {producto.stock}
                                    </span>
                                </div>
                                <p className="mt-2 text-sm text-gray-400 flex-1 leading-relaxed">
                                    {producto.description}
                                </p>
                                
                                {/* Precio y Botón */}
                                <div className="mt-8 flex items-center justify-between">
                                    <p className="text-3xl font-black text-white">
                                        <span className="text-xl text-indigo-400 mr-1">$</span>
                                        {producto.price}
                                    </p>
                                    <button className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2.5 px-5 rounded-xl shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 active:scale-95 cursor-pointer flex items-center gap-2">
                                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                                        Comprar
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                
            </div>
        </div>
    );
};

export default Catalogo;